package com.example;

import javax.swing.*;

import java.sql.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Query {

    // FIXARE ORDINE QUERY 
        public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/strumenti";
        String username = "francesco";
        String password = "root"; 

        JFrame frame = new JFrame();
        frame.setSize(800, 600);
        frame.setTitle("Interfaccia query");

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(4, 4));


        JButton b1 = new JButton("Creare un nuovo account ");
        JButton b2 = new JButton("Selezionare un prodotto ");
        JButton b3 = new JButton("Acquistare un prodotto");
        JButton b4 = new JButton("Creare un nuovo ordine ");
        JButton b5 = new JButton("Affidare l’ordine a un corriere");
        JButton b6 = new JButton("Trovare il numero di strumenti acquistati ");
        JButton b7 = new JButton("Contare numero prodotti ");
        JButton b8 = new JButton("Aggiornare disponibilità prodotti");
        JButton b9 = new JButton("Inserire descrizione prodotto ");
        JButton b10 = new JButton("Aggiornare password account ");
        JButton b11 = new JButton("Contare il numero  di ordini affidato al corriere "); 
        
        b1.addActionListener( new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    String query1 = "INSERT IGNORE INTO Account (codAccount, cfCodAccount) VALUES ('ACC002', 'CF12345678901234');";
                
                    st.executeUpdate(query1);
                    JOptionPane.showMessageDialog(null, "Nuovo account Creato");                    
                    
                    st.close();
                    con.close();
        
                } catch (SQLException e) {
                    System.out.println("connessione fallita");
                    e.printStackTrace();
                }
            }
        });
        
        b2.addActionListener( new ActionListener() {
        
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    String query2 = "INSERT IGNORE INTO Seleziona (UtenteCF, CodiceProdotto) VALUES ('CF12345678901234', 1);";
                
                    st.executeUpdate(query2);
                    JOptionPane.showMessageDialog(null, "Prodotto selezionato");
                    
                    st.close();
                    con.close();
        
                } catch (SQLException e) {
                    System.out.println("connessione fallita");
                    e.printStackTrace();
                }
            }
        });

        
        b3.addActionListener( new ActionListener() {
        
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    String query3 = "INSERT IGNORE INTO Inserito (CodiceProdotto, codiceCarrello) VALUES (1, 1); ";
                    String q3= "INSERT IGNORE INTO Ordine (Carrello_CodiceCarrello, CodiceOrdine, Corriere_CodiceCorriere) VALUES (1, 2, 1);";
                
                    st.executeUpdate(query3);
                    st.executeUpdate(q3);
                    JOptionPane.showMessageDialog(null, "Prodotto acquistato 5");
                    
                    st.close();
                    con.close();
        
                } catch (SQLException e) {
                    System.out.println("connessione fallita");
                    e.printStackTrace();
                }
            }
        });
        b4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    String query1 = "INSERT IGNORE INTO Carrello (CodiceCarrello) VALUES (4);";
                    String q2 = "INSERT IGNORE INTO Ordine (Carrello_CodiceCarrello, CodiceOrdine, Corriere_CodiceCorriere) VALUES (4, 3, 1);";
                    st.executeUpdate(query1); 
                    st.executeUpdate(q2);
                    JOptionPane.showMessageDialog(null, "Nuovo ordine creato");
                    
                    st.close();
                    con.close();
            
                } catch (SQLException e) {
                    System.out.println("Connessione fallita");
                    e.printStackTrace();
                }
            }
        });
        
        b5.addActionListener( new ActionListener() {
        
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    String query2 ="UPDATE Ordine SET Corriere_CodiceCorriere = 2 WHERE CodiceOrdine = 3;";
                
                    st.executeUpdate(query2);
                    JOptionPane.showMessageDialog(null, "Ordine affidato ad un corriere");
                    
                    st.close();
                    con.close();
        
                } catch (SQLException e) {
                    System.out.println("connessione fallita");
                    e.printStackTrace();
                }
            }
        });
        

        b6.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    
                    // Aggiungi la tua query SQL qui
                    String query = "SELECT COUNT(s.CodiceProdotto) AS NumeroStrumentiAcquistati " +
                                   "FROM Seleziona s " +
                                   "JOIN Inserito i ON s.CodiceProdotto = i.CodiceProdotto " +
                                   "JOIN Carrello c ON i.CodiceCarrello = c.CodiceCarrello " +
                                   "JOIN Ordine o ON c.CodiceCarrello = o.Carrello_CodiceCarrello;";
                    
                    // Esegui la query
                    ResultSet rs = st.executeQuery(query);
                    
                    // Ottenere i risultati e fare qualcosa con essi, come mostrare in una finestra di dialogo
                    if (rs.next()) {
                        int numeroStrumentiAcquistati = rs.getInt("NumeroStrumentiAcquistati");
                        JOptionPane.showMessageDialog(null, "Numero di strumenti acquistati: " + numeroStrumentiAcquistati);
                    }
                    
                    st.close();
                    con.close();
                } catch (SQLException e) {
                    System.out.println("Connessione fallita");
                    e.printStackTrace();
                }
            }
        });
        

        b7.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    String query7 = "SELECT COUNT(*) AS NumProdotti FROM Prodotto";
                    
                    ResultSet resultSet = st.executeQuery(query7);
                    resultSet.next();
                    int numProdotti = resultSet.getInt("NumProdotti");
                    
                    JOptionPane.showMessageDialog(null, "Numero di prodotti: " + numProdotti, "Successo", JOptionPane.INFORMATION_MESSAGE);
                    
                    st.close();
                    con.close();
            
                } catch (SQLException e) {
                    System.out.println("Connessione fallita");
                    e.printStackTrace();
                }
            }
        });
        
        
        b8.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    String query8 = "UPDATE Prodotto SET Disponibilità = 'Non disponibile' WHERE CodiceProdotto = 1";
                    
                    st.executeUpdate(query8);
                    
                    JOptionPane.showMessageDialog(null, "Aggiornamento completato.");
                    
                    st.close();
                    con.close();
            
                } catch (SQLException e) {
                    System.out.println("Connessione fallita");
                    e.printStackTrace();
                }
            }
        });
        
        b9.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    String query9 = "UPDATE Prodotto SET Descrizione = 'Nuova descrizione del prodotto' WHERE CodiceProdotto = 2;";
                    st.executeUpdate(query9);
                    JOptionPane.showMessageDialog(null, "Descrizione prodotto aggiornata", "Successo", JOptionPane.INFORMATION_MESSAGE);
                    
                    st.close();
                    con.close();
        
                } catch (SQLException e) {
                    System.out.println("connessione fallita");
                    e.printStackTrace();
                }
            }
        });
        
        
        b10.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    String query10 = "UPDATE Utente SET pw = 'nuovaPassword789' WHERE cf = (SELECT cfCodAccount FROM Account WHERE codAccount = ' A001');";
                
                    st.executeUpdate(query10);
                    
                    JOptionPane.showMessageDialog(null, "Password Aggiornata", "Successo", JOptionPane.INFORMATION_MESSAGE);
                    
                    st.close();
                    con.close();
        
                } catch (SQLException e) {
                    System.out.println("connessione fallita");
                    e.printStackTrace();
                }
            }
        });
        
        b11.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent arg0) {
                try {
                    Connection con = DriverManager.getConnection(url, username, password);
                    Statement st = con.createStatement();                   
                    System.out.println("Connessione riuscita\n\n\n");
                    String query11 = "SELECT COUNT(*) AS NumeroOrdini FROM Ordine WHERE Corriere_CodiceCorriere = 2";
                
                    ResultSet resultSet = st.executeQuery(query11);
                    resultSet.next();
                    int numeroOrdini = resultSet.getInt("NumeroOrdini");
                    
                    JOptionPane.showMessageDialog(null, "Numero di ordini con Corriere CodiceCorriere = 2: " + numeroOrdini, "Successo", JOptionPane.INFORMATION_MESSAGE);
                    
                    st.close();
                    con.close();
        
                } catch (SQLException e) {
                    System.out.println("connessione fallita");
                    e.printStackTrace();
                }
            }
        });
        
            

        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        panel.add(b4);
        panel.add(b5);
        panel.add(b6);
        panel.add(b7);
        panel.add(b8);
        panel.add(b9);
        panel.add(b10);
        panel.add(b11);
        
        frame.add(panel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        }
}